export const DB_NAME = "PostApp"
